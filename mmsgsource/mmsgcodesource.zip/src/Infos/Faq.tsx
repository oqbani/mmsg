

const Faq = () => {
  return (
    <div>
      
    </div>
  )
}

export default Faq
