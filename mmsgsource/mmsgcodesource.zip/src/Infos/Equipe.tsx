

const Equipe = () => {
  return (
    <div>
      
    </div>
  )
}

export default Equipe
