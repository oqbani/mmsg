

const payment = () => {
  return (
    <div>
      
    </div>
  )
}

export default payment
