import React, { useEffect } from 'react'

const Infos:React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])
  return (
    <div>
      
    </div>
  )
}

export default Infos
