import React, { useEffect } from 'react'

const Blog:React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])
  return (
    <div>
      
    </div>
  )
}

export default Blog
