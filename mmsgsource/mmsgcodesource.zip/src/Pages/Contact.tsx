import React, { useEffect } from "react";
import { useTranslation } from "react-i18next";
import { BsInstagram, BsLinkedin } from "react-icons/bs";
import { FaClock, FaFacebookSquare, FaPhoneAlt } from "react-icons/fa";
import { FaLocationDot } from "react-icons/fa6";
import { IoShareSocialSharp } from "react-icons/io5";
import { MdEmail } from "react-icons/md";
import { TfiYoutube } from "react-icons/tfi";
import { Link } from "react-router-dom";

// Import Swiper
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import { Navigation } from "swiper/modules";

const Contact: React.FC = () => {
  const [t] = useTranslation("global");
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <div className="">
      <div className="page-head contact-head" data-aos="fade-right">
        <div className="container page-head-content">
          <h1>{t("contact.contact")}</h1>
          <p className=" fs-4">{t("soins-content.desc")}</p>
          <p>
            <Link
              to={"/"}
              className=" text-white"
              style={{ textDecoration: "none" }}
            >
              {t("nav-content.accueil")}
            </Link>{" "}
            | {t("contact.contact")}
          </p>
        </div>
        <div className="contact-blur w-100 h-100"></div>
      </div>
      <h1 className="title my-5" data-aos="fade-left">
        {t("contact.title")} <span>{t("contact.soustitle")}</span>
      </h1>
      <div className="contact-form my-5 py-5">
        <div className="contact container">
          <div className="form-content">
            <div className="d-flex align-items-center gap-5">
              <IoShareSocialSharp className="i" />
              <div>
                <h2>{t("contact.media")}</h2>

                <div className="media pt-3 d-flex gap-3">
                  <FaFacebookSquare className="i fs-5 me-2" />
                  <BsInstagram className="i fs-5 me-2" />
                  <BsLinkedin className="i fs-5 me-2" />
                  <TfiYoutube className="i fs-5" />
                </div>
              </div>
            </div>
            <div className="d-flex align-items-center gap-5">
              <FaClock className="i" />
              <div>
                <h2>{t("contact.horaire-title")}</h2>
                <h5>{t("contact.horaire")}</h5>
              </div>
            </div>
            <div className="d-flex align-items-center gap-5">
              <MdEmail className="i" />
              <div>
                <h2>{t("contact.form-email")}</h2>
                <h5>infos@mmsg.be</h5>
              </div>
            </div>
            <div className="d-flex align-items-center gap-5">
              <FaLocationDot className="i" />
              <div>
                <h2>{t("contact.form-adress")}</h2>
                <h5>187, RueWayez à 1070 Anderlecht</h5>
              </div>
            </div>
            <div className="d-flex align-items-center gap-5">
              <FaPhoneAlt className="i" />
              <div>
                <h2>{t("contact.form-tel")}</h2>
                <h5>+32 (0) 2 527 97 90</h5>
              </div>
            </div>
          </div>
          <div className="form-content">
            <h1 className=" text-center">
              {t("modal.form-title")}
            </h1>
            <form action="">
              <div>
                <label htmlFor="">{t("contact.form-nom")}</label>
                <input type="text" />
              </div>
              <div>
                <label htmlFor="">{t("contact.form-prenom")}</label>
                <input type="text" />
              </div>
              <div>
                <label htmlFor="">{t("contact.form-email")}</label>
                <input type="text" />
              </div>
              <div>
                <label htmlFor="">{t("contact.form-tel")}</label>
                <input type="text" />
              </div>
              <div>
                <label htmlFor="">{t("contact.form-message")}</label>
                <textarea />
              </div>

              <button>{t("modal.form-btn")}</button>
            </form>
          </div>
        </div>
      </div>
      <div className="container contact my-5">
        <Swiper navigation={true} loop={true} modules={[Navigation]} className="mySwiper">
          <SwiperSlide>
            <img src="/mmsg-bg-1.jpg" alt="" />
          </SwiperSlide>
          <SwiperSlide>
            <img src="/mmsg-bg-2.jpg" alt="" />
          </SwiperSlide>
          <SwiperSlide>
            <img src="/mmsg-bg-3.jpg" alt="" />
          </SwiperSlide>
          <SwiperSlide>
            <img src="/mmsg-bg-4.jpg" alt="" />
          </SwiperSlide>
          <SwiperSlide>
            <img src="/mmsg-maps.jpg" alt="" />
          </SwiperSlide>
        </Swiper>
      </div>

      <div className="w-100 h-100">
        <iframe
          src="https://maps.app.goo.gl/1jgTSXM5a1t5zztV8"
          width="100%"
          height="450"
          style={{ border: "0", minHeight: "30rem" }}
          loading="lazy"
        ></iframe>
      </div>
    </div>
  );
};

export default Contact;
