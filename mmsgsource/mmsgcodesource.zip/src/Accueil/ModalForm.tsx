import React, { useRef } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import emailjs, { EmailJSResponseStatus } from "@emailjs/browser";
import { SyntheticEvent } from "react";
import { useTranslation } from "react-i18next";
import { FaPaperPlane } from "react-icons/fa";
import "react-time-picker/dist/TimePicker.css";
import "react-clock/dist/Clock.css";

const ModalForm: React.FC = () => {
  const [t] = useTranslation("global");

  const formRef = useRef<HTMLFormElement>(null);

  const sendEmail = (e: SyntheticEvent) => {
    e.preventDefault();

    const form = e.currentTarget as HTMLFormElement;

    emailjs
      .sendForm("service_j7jvszl", "template_drvmjok", form, {
        publicKey: "Nsy9KChA4YTJVsgzi",
      })
      .then(
        (response: EmailJSResponseStatus) => {
          console.log("SUCCESS!", response);
        },
        (error: any) => {
          console.log("FAILED...", error.text);
        }
      );
  };

  const validationSchema = Yup.object().shape({
    from_firstname: Yup.string().required(t("modal-validation.nom")),
    from_lastname: Yup.string().required(t("modal-validation.prenom")),
    from_phone: Yup.string().required(t("modal-validation.phone")),
    from_date: Yup.string().required(t("modal-validation.date")),
    from_email: Yup.string()
      .email("Email invalide")
      .required(t("modal-validation.email")),
    message: Yup.string().required(t("modal-validation.message")),
  });

  const onSubmit = () => {
    emailjs
      .sendForm("service_j7jvszl", "template_drvmjok", formRef.current!, {
        publicKey: "Nsy9KChA4YTJVsgzi",
      })
      .then(
        (response: EmailJSResponseStatus) => {
          console.log("SUCCESS!", response);
        },
        (error: any) => {
          console.log("FAILED...", error.text);
        }
      );
  };

  const formik = useFormik({
    initialValues: {
      from_firstname: "",
      from_lastname: "",
      from_email: "",
      from_phone: "",
      from_doctors: "",
      from_date: "",
      message: "",
    },
    validationSchema,
    onSubmit,
  });
  const handleSubmit = (e: SyntheticEvent) => {
    sendEmail;
    e.preventDefault();
    formik.handleSubmit();
  };
  return (
    <div>
      <form ref={formRef} onSubmit={formik.handleSubmit}>
        <div>
          <input
            type="text"
            placeholder={t("modal.form-nom")}
            value={formik.values.from_firstname}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
          />
          {formik.touched.from_firstname && formik.errors.from_firstname ? (
            <div className="error">{formik.errors.from_firstname} *</div>
          ) : null}
        </div>
        <div>
          <input
            type="text"
            placeholder={t("modal.form-prenom")}
            value={formik.values.from_lastname}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
          />
          {formik.touched.from_lastname && formik.errors.from_lastname ? (
            <div className="error">{formik.errors.from_lastname} *</div>
          ) : null}
        </div>
        <div>
          <input
            type="text"
            placeholder={t("modal.form-email")}
            value={formik.values.from_email}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
          />
          {formik.touched.from_email && formik.errors.from_email ? (
            <div className="error">{formik.errors.from_email} *</div>
          ) : null}
        </div>
        <div>
          <input
            type="text"
            placeholder={t("modal.form-tel")}
            value={formik.values.from_phone}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
          />
          {formik.touched.from_phone && formik.errors.from_phone ? (
            <div className="error">{formik.errors.from_phone} *</div>
          ) : null}
        </div>
        <div>
          <select
            name=""
            id=""
            value={formik.values.from_doctors}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
          >
            <option selected disabled >
              {t("modal.medecins")}
            </option>
            <option value="Dr. ZEKHNINI Mohammed">Dr. ZEKHNINI Mohammed</option>
            <option value="Dr. WASHIWAPA Rachel">Dr. WASHIWAPA Rachel</option>
            <option value="Dr. EL HAJJAMI Fatiha">Dr. EL HAJJAMI Fatiha</option>
            <option value="Dr. LIGOT Nadine">Dr. LIGOT Nadine</option>
            <option value="Dr. RAMADAN Sobhi">Dr. RAMADAN Sobhi</option>
            <option value="Dr. CHERQUAOUI Ibtissam">
              Dr. CHERQUAOUI Ibtissam
            </option>
            <option value="Dr. PIEQ Clémence">Dr. PIEQ Clémence</option>
            <option value="Dr. BENENGUEYE Lorenzo">
              Dr. BENENGUEYE Lorenzo
            </option>
            <option value="Dr. NINDABA Divine">Dr. NINDABA Divine</option>
            <option value="Dr. ELKHIYAT Iman">Dr. ELKHIYAT Iman</option>
            <option value="Dr. BELKAHIA Walid">Dr. BELKAHIA Walid</option>
          </select>
          {formik.touched.from_doctors && formik.errors.from_doctors ? (
            <div className="error">{formik.errors.from_doctors}</div>
          ) : null}
        </div>
        <div>
          <input
            type="date"
            placeholder={t("modal.form-date")}
            value={formik.values.from_date}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
          />
          {formik.touched.from_date && formik.errors.from_date ? (
            <div className="error">{formik.errors.from_date} *</div>
          ) : null}
        </div>
        <div>
          <input
            className="input-time text-center"
            type="time"
            placeholder="08:30"
            min="08:30"
            max="18:00"
          />
          {formik.touched.from_date && formik.errors.from_date ? (
            <div className="error">{formik.errors.from_date} *</div>
          ) : null}
        </div>
        <div className="d-flex flex-column justify-content-center align-items-center">
          <textarea
            value={formik.values.message}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
            placeholder={t("modal.form-message")}
          ></textarea>
          {formik.touched.message && formik.errors.message ? (
            <div className="error">{formik.errors.message} *</div>
          ) : null}
          <button
            onSubmit={handleSubmit}
            type="submit"
            className="mt-4 px-4 d-flex justify-content-between align-items-center"
          >
            {t("modal.form-btn")} <FaPaperPlane />{" "}
          </button>
        </div>
      </form>
    </div>
  );
};

export default ModalForm;
