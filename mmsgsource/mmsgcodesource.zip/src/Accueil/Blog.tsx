import React from "react";
import { useTranslation } from "react-i18next";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination, FreeMode, Autoplay } from "swiper/modules";

// Swiper
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/free-mode";

const Blog: React.FC = () => {
  const [t] = useTranslation("global");

  const blog = [
    {
      title: t("blog.0.title"),
      date: t("blog.0.date"),
      cat: t("blog.0.cat"),
      img: t("blog.0.img"),
      content: t("blog.0.content"),
    },
    {
      title: t("blog.1.title"),
      date: t("blog.1.date"),
      cat: t("blog.1.cat"),
      img: t("blog.1.img"),
      content: t("blog.1.content"),
    },
    {
      title: t("blog.2.title"),
      date: t("blog.2.date"),
      cat: t("blog.2.cat"),
      img: t("blog.2.img"),
      content: t("blog.2.content"),
    },
    {
      title: t("blog.3.title"),
      date: t("blog.3.date"),
      cat: t("blog.3.cat"),
      img: t("blog.3.img"),
      content: t("blog.3.content"),
    },
    ,
    {
      title: t("blog.4.title"),
      date: t("blog.4.date"),
      cat: t("blog.4.cat"),
      img: t("blog.4.img"),
      content: t("blog.4.content"),
    },
    {
      title: t("blog.5.title"),
      date: t("blog.5.date"),
      cat: t("blog.5.cat"),
      img: t("blog.5.img"),
      content: t("blog.5.content"),
    },
  ];

  return (
    <div className="blog my-5">
      <div className="container">
        <div className="text-center mb-5">
          <h1 className="title text-center"
            data-aos="fade-up-right">
            {t("blog-content.title")}
            <span> {t("blog-content.soustitle")}</span>
          </h1>
        </div>
        {/* <div>
          <div className="blog-cards">
            {blog.map((b, index) => (
              <div className="blog-card" key={index}>
                <div>
                  <img src={b?.img} alt="" />
                </div>
                <div className="blog-content mt-4">
                  <h3>{b?.title}</h3>
                  <div>
                    <p>{b?.date}</p>|<a href="">{b?.cat}</a>
                  </div>
                  <p>{b?.content}</p>
                </div>
              </div>
            ))}
          </div>
        </div> */}
      </div>

      <div>
        <Swiper
          pagination={true}
          modules={[Pagination]}
          className="mt-5 d-none"
        >
          <SwiperSlide>Slide 1</SwiperSlide>
          <SwiperSlide>Slide 2</SwiperSlide>
          <SwiperSlide>Slide 3</SwiperSlide>
          <SwiperSlide>Slide 4</SwiperSlide>
          <SwiperSlide>Slide 5</SwiperSlide>
          <SwiperSlide>Slide 6</SwiperSlide>
          <SwiperSlide>Slide 7</SwiperSlide>
          <SwiperSlide>Slide 8</SwiperSlide>
          <SwiperSlide>Slide 9</SwiperSlide>
        </Swiper>
      </div>

      <div className="container d-flex justif-content-center align-items-center flex-column">
        <Swiper
          navigation
          pagination={{ clickable: true }}
          freeMode={true}
          autoplay={{ delay: 2000 }}
          modules={[Navigation, Pagination, FreeMode, Autoplay]}
          className="mySwiper"
          spaceBetween={20}
          breakpoints={{
            480: {
              slidesPerView: 1,
            },
            868: {
              slidesPerView: 2,
            },
            968: {
              slidesPerView: 3,
            },
            1468: {
              slidesPerView: 3,
            },
          }}
        >
          <div className="blog-cards">
            {blog.map((b, index) => (
              <SwiperSlide key={index}>
                <div className="blog-card">
                  <div  data-aos="zoom-in">
                    <img src={b?.img} className="" alt="" />
                  </div>
                  <div className="blog-content mt-4">
                    <h3 data-aos="zoom-in">{b?.title}</h3>
                    <div data-aos="zoom-in">
                      <p>{b?.date}</p>|<a href="">{b?.cat}</a>
                    </div>
                    <p data-aos="zoom-in">{b?.content}</p>
                  </div>
                </div>
              </SwiperSlide>
            ))}
          </div>
        </Swiper>
        <button data-aos="zoom-in" className=" mt-3" style={{width: "20rem"}}>{t('blog-content.btn')}</button>
      </div>
    </div>
  );
};

export default Blog;
