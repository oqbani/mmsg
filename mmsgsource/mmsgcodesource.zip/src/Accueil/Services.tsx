import React from "react";
import { useTranslation } from "react-i18next";
import { BsArrowRight } from "react-icons/bs";

const Services: React.FC = () => {
  const [t] = useTranslation("global");

  const soins = [
    {
      title: t("soins.0.title"),
      content: "",
      img: t("soins.0.img"),
    },
    {
      title: t("soins.1.title"),
      content: "",
      img: t("soins.1.img"),
    },
    {
      title: t("soins.2.title"),
      content: "",
      img: t("soins.2.img"),
    },
    {
      title: t("soins.3.title"),
      content: "",
      img: t("soins.3.img"),
    },
    {
      title: t("soins.4.title"),
      content: "",
      img: t("soins.4.img"),
    },
    {
      title: t("soins.5.title"),
      content: "",
      img: t("soins.5.img"),
    }
  ];

  return (
    <div className="soins-container container my-5">
      <div className=" text-center mb-5">
        <h1 className="title text-center"
            data-aos="fade-up-right">
          {t("soins-content.title")}
          <span> {t("soins-content.soustitle")}</span>
        </h1>
      </div>
      <div className="soins-content-container">
        {soins.map((s, index) => (
          <div className="soins-card" key={index}>
            <div data-aos="zoom-in">
              <img src={s.img} alt="" />
            </div>
            <div className="soins-content" data-aos="zoom-in">
              <button className=" fw-bolder d-flex justify-content-between align-items-center px-2" >{s.title} <BsArrowRight className="fs-3" /></button>
            </div>
          </div>
        ))}
      </div>
      <div className=" text-center mt-5" data-aos="zoom-in">
        <button className=" fw-bolder">{t("soins-content.btn-soins")}</button>
      </div>
    </div>
  );
};

export default Services;
