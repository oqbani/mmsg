import React from 'react'

const ModalPresc:React.FC = () => {
  return (
    <div>
      
    </div>
  )
}

export default ModalPresc
