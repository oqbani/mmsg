import React from "react";
import { useTranslation } from "react-i18next";
import logo_fr from "../assets/imgs/FR.png";
import logo_en from "../assets/imgs/EN.png";
import { FaPhoneAlt, FaRegClock } from "react-icons/fa";
import { BsInstagram, BsLinkedin } from "react-icons/bs";
import { MdAlternateEmail } from "react-icons/md";
import { TfiYoutube } from "react-icons/tfi";
import { ImFacebook2 } from "react-icons/im";

const Header: React.FC = () => {
  const [t, i18n] = useTranslation("global");

  const handleLanguageChange = (newLang: string) => {
    i18n.changeLanguage(newLang);
  };

  return (
    <div className="header">
      <div className="container d-flex justify-content-between align-items-center p-1">
        <div className="header-media h-100 d-flex align-items-center justify-content-center gap-4">
          <li>
            <FaPhoneAlt className="i me-2" />
            {t("footer.tel")}
          </li>
          <li>
            <MdAlternateEmail className="i me-2" />
            {t("footer.email")}
          </li>
          <li>
            <FaRegClock className="i me-2" />
            {t("header.horaire")}
          </li>
        </div>
        <div className=" d-flex gap-5">
          <div className="media-header">
            <ImFacebook2 className="fa fs-3 me-2" />
            <BsInstagram className="fa fs-5 me-2" />
            <BsLinkedin className="fa fs-5 me-2" />
            <TfiYoutube className="fa fs-5" />
          </div>
          <div>
            <img
              src={logo_fr}
              style={{ width: "1.5rem", marginRight: ".5rem" }}
              onClick={() => handleLanguageChange("fr")}
              alt=""
            />
            <img
              src={logo_en}
              style={{ width: "1.5rem" }}
              onClick={() => handleLanguageChange("en")}
              alt=""
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Header;
