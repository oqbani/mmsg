import React from "react";
import { useTranslation } from "react-i18next";
import { BsInstagram, BsLinkedin } from "react-icons/bs";
import { FaFacebookSquare, FaPhoneAlt, FaRegClock } from "react-icons/fa";
import { FaLocationDot } from "react-icons/fa6";
import { MdAlternateEmail, MdKeyboardArrowRight } from "react-icons/md";
import { TfiYoutube } from "react-icons/tfi";
import logo from "/mmsg-logo.png";

const Footer: React.FC = () => {
  const [t] = useTranslation("global");
  return (
    <div className="footer">
      <div className="container">
        <ul className="">
          <div
            className="d-flex gap-3 align-items-center"
          >
            <img src={logo} style={{ width: "4rem" }} />
            <h3 className=" fw-bolder mb-5" style={{ color: "#333" }}>
              MMSG
            </h3>
          </div>
          <li>
            <FaRegClock className=" fs-5 me-2" />
            {t("footer.horaire")}
          </li>
          <li>
            <FaLocationDot className=" fs-5 me-2" /> {t("footer.adress")}
          </li>
          <li>
            <FaPhoneAlt className=" fs-5 me-2" /> {t("footer.tel")}
          </li>
          <li>
            <MdAlternateEmail className=" fs-5 me-2" /> {t("footer.email")}
          </li>
          <div className="media pt-3 d-flex gap-3">
            <FaFacebookSquare className="i fs-5 me-2" />
            <BsInstagram className="i fs-5 me-2" />
            <BsLinkedin className="i fs-5 me-2" />
            <TfiYoutube className="i fs-5" />
          </div>
        </ul>
        <ul>
          <h2>{t("footer.mmsg")}</h2>
          <li>
            <MdKeyboardArrowRight />
            {t("footer.li-1")}
          </li>
          <li>
            <MdKeyboardArrowRight />
            {t("footer.li-2")}
          </li>
          <li>
            <MdKeyboardArrowRight />
            {t("footer.li-3")}
          </li>
          <li>
            <MdKeyboardArrowRight />
            {t("footer.li-4")}
          </li>
          <li>
            <MdKeyboardArrowRight />
            {t("footer.li-5")}
          </li>
        </ul>
        <ul>
          <h2>{t("footer.liens")}</h2>
          <li>
            <MdKeyboardArrowRight />
            {t("footer.contact")}
          </li>
          <li>
            <MdKeyboardArrowRight />
            {t("footer.faq")}
          </li>
          <li>
            <MdKeyboardArrowRight />
            {t("footer.cpas")}
          </li>
          <li>
            <MdKeyboardArrowRight />
            {t("footer.prescription")}
          </li>
          <li>
            <MdKeyboardArrowRight />
            {t("footer.rdv")}
          </li>
        </ul>
      </div>
      <div className="copy-right">
        <h6>{t("footer.copy-right")}</h6>
      </div>
    </div>
  );
};

export default Footer;
