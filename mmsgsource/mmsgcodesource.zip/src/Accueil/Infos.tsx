import React from "react";
import { useTranslation } from "react-i18next";
import { BsArrowRight } from "react-icons/bs";
import { IoInformationCircleOutline } from "react-icons/io5";

const Infos: React.FC = () => {
  const [t] = useTranslation("global");

  const infos = [
    {
      title: t("infos.0.title"),
      content: t("infos.0.content"),
      btn: t("infos.0.btn"),
    },
    {
      title: t("infos.1.title"),
      content: t("infos.1.content"),
      btn: t("infos.1.btn"),
    },
    {
      title: t("infos.2.title"),
      content: t("infos.2.content"),
      btn: t("infos.2.btn"),
    },
    {
      title: t("infos.3.title"),
      content: t("infos.3.content"),
      btn: t("infos.3.btn"),
    },
  ];
  return (
    <div className="infos-container my-5">
      <div className=" text-center mb-5">
        <h1 className="title text-center"
            data-aos="fade-up-right">
          {t("infos-content.title")}
          <span> {t("infos-content.soustitle")}</span>
        </h1>
      </div>
      <div className="infos">
        <div className="container">
          <div className="infos-cards">
            {infos.map((info, index) => (
              <div className="infos-card" data-aos="zoom-in" key={index}>
                <div data-aos="zoom-in">
                  <h3 className=" d-flex justify-content-between align-items-center">
                    <IoInformationCircleOutline className="fs-2" />
                    {info.title}
                  </h3>
                </div>
                <p data-aos="zoom-in">{info.content}</p>
                <button data-aos="zoom-in" className=" fw-bolder d-flex justify-content-between align-items-center px-2">
                  {info.btn} <BsArrowRight className="fs-3" />
                </button>
              </div>
            ))}
          </div>
        </div>
        <div className="infos-blur w-100 h-100"></div>
      </div>
      <div className="w-100 d-flex justify-content-center text-center mt-5" data-aos="zoom-in">
        <button className="info-btn fw-bolder">
          {t("infos-content.btn")} <BsArrowRight className=" fs-3" />
        </button>
      </div>
    </div>
  );
};

export default Infos;
